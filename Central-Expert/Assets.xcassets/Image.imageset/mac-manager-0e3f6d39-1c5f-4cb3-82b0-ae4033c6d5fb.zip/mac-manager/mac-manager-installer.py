#!/usr/bin/python3

import os
import subprocess
from pathlib import Path
import sys

install_dir = '/opt/irede/mac-manager'
ssl_dir = '/opt/irede/mac-manager/ssl'
resources_dir = ''
files_to_cp = ['mac-manager.py', 'cron-setup.sh', 'cron-unsetup.sh']

def log(l):
    print(l)

def create_dirs(p):
    Path(p).mkdir(parents=True, exist_ok=True)

def config():
    log('Creating Directories')
    create_dirs(install_dir)
    # create_dirs(create_mac_manager)
    log(f'Copying files to {install_dir}...')
    for i in files_to_cp:
        subprocess.run(['cp', f'{os.getcwd()}/{i}', f'{install_dir}/'])
    
    log('Copying SSL files...')
    # Copy SSL
    create_dirs(ssl_dir)
    subprocess.run(['cp', f'{os.getcwd()}/ssl/consolidate.pem', f'{ssl_dir}/'], check=True)

    # Adding permission and running Cron-setup
    subprocess.run(['chmod', '+x', f'{install_dir}/cron-setup.sh'], check=True)
    subprocess.run(['sudo','bash',f'{install_dir}/cron-setup.sh'], check=True)

if __name__ == '__main__':
    error = False
    try:
        log('Installing dependencies...')
        #Installing requests
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'requests','urllib3==1.26.6'])
        log('Installer started...')
        config()
    except Exception as e:
        error = True
        log('Problem With script:')
        log(e)

    if error:
        log('Algo aconteceu... Tente novamente.')
    else:
        log('Instalação concluída. Pode fechar o programa.')
