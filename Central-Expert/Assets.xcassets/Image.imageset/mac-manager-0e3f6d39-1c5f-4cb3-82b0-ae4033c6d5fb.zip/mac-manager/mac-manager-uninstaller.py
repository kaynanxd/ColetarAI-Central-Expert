#!/usr/bin/python3

import os
import subprocess
from pathlib import Path
import sys

install_dir = '/opt/irede/mac-manager'
ssl_dir = '/opt/irede/mac-manager/ssl'
resources_dir = ''
files_to_cp = ['mac-manager.py', 'cron-setup.sh', 'cron-unsetup.sh', 'crontab.txt']

def log(l):
    print(l)

def rmdir(d):
    direc = Path(d)
    for item in direc.iterdir():
        if item.is_dir():
            rmdir(item)
        else:
            item.unlink()
    direc.rmdir()

def config():
    log('Creating Directories')
    rmdir(install_dir)
    subprocess.run(['chmod', '+x', f'./cron-unsetup.sh'], check=True)
    subprocess.run([f'./cron-unsetup.sh'], check=True)

if __name__ == '__main__':
    error = False
    try:
        log('Uninstall started...')
        config()
    except Exception as e:
        error = True
        log('Problem With script:')
        log(e)

    if error:
        log('Algo aconteceu... Tente novamente.')
    else:
        log('Desinstalação concluída. Pode fechar o programa.')