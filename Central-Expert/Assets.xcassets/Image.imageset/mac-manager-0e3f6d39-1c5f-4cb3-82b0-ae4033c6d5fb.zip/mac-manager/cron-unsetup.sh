#!/bin/bash
export MANAGER=mac-manager.py;

# Asking for root password in order to add cron job
pw="$(osascript -e 'Tell application "System Events" to display dialog "Senha root para configurar Mac:" default answer "" with hidden answer' -e 'text returned of result' 2>/dev/null)"
echo "$pw" | sudo -S crontab -u root -l

# Remove from crontab where $MANAGER is present
sudo crontab -u root -l | grep -v "$MANAGER"  | sudo crontab -u root -
