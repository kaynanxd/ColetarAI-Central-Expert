#!/bin/bash

export MANAGER='mac-manager.py';
printf "Manager: "
echo $MANAGER

export MANAGER_PATH='/opt/irede/mac-manager';
printf "Manager Path: "
echo $MANAGER_PATH

# Make $MANAGER executable
chmod +x ./$MANAGER

mac_name="$(osascript -e 'Tell application "System Events" to display dialog "Qual o nome desse Macbook?\n(Nome cadastrado no Portal)" default answer ""' -e 'text returned of result' 2>/dev/null)"
export result="*/10 * * * * cd $MANAGER_PATH && MAC_NAME='$mac_name' python3 ./$MANAGER > ./irede.log 2> ./irede_err.log"

# Asking for root password in order to add cron job
pw="$(osascript -e 'Tell application "System Events" to display dialog "Senha root para configurar Mac:" default answer "" with hidden answer' -e 'text returned of result' 2>/dev/null)"
echo "$pw" | sudo -S crontab -u root -l

(crontab -l ; echo "$result") 2>&1 | grep -v "no crontab" | sort | uniq | sudo crontab -u root -
