#!/usr/bin/python3

import datetime
import sys
import os
from typing import List
import platform
import requests
import time

BASE_URL = 'https://schedule.iosi.com.br:8443/api/v1/schedule'
HEADERS = {'API_KEY': 'lds@iosi'}
COMPUTER_NAME = os.environ['MAC_NAME']
ADMIN_USERS = ['root', 'iosi', 'lds']

os_name = platform.system()

# Create logs to system

def log(l):
    print(l)
    with open('logs', 'a') as f:
        f.write(l + '\n')


def get_current_logged_users() -> List[str]:
    """
    Get current logged users.

    :return: List of users.
    """
    if os_name == 'Linux':
        cmd = 'w -hs | cut --delimiter " " --fields 1'
        current_user: str = os.popen(cmd).read().split('\n')
        current_user = list(filter(lambda z: z != '', current_user))
    else:
        cmd = 'who | grep console | cut -d " " -f 1'
        current_user: List[str] = os.popen(cmd).read().split('\n')
        current_user = list(filter(lambda z: z != '', current_user))

    log(f'Current Looged Users user are: "{current_user}".')

    if current_user is None or current_user == '' or current_user == '$USER':
        log('User not Found')
        sys.exit(1)

    return current_user if isinstance(current_user, list) else [current_user]


def logout_user(user: str):
    """
    Logout requested user
    :param user:
    :return:
    """
    log(f'Logging out {user}')

    if user in ADMIN_USERS:
        log('Cannot kill admins user\'s process.')
        return
    if user == 'root':
        log('Cannot Kill root process')
        return

    bash_script_rustdesk = '''
     kill -9 $(ps aux | grep rustdesk --server | awk '{print $2}')
    '''
    os.system(bash_script_rustdesk)

    cmd = f'pkill -KILL -u {user}'

    log(f'Should run {cmd}')
    return os.system(cmd)


class UserResponse:
    """
    Mapper class for Request.
    """
    computer: str
    user_mac: str

    def __init__(self): pass

    @staticmethod
    def from_json(json: dict) -> 'UserResponse':
        user = UserResponse()
        user.computer = json.get('computer')
        user.user_mac = json.get('macUser')
        return user

    def __repr__(self) -> str:
        return self.user_mac


class ComputerResponse:
    """
    Mapper class for Request.
    """
    name: str
    available: bool = False

    def __init__(self): pass

    @staticmethod
    def from_json(json: dict) -> 'ComputerResponse':
        computer = ComputerResponse()
        computer.name = json.get('name')
        computer.available = json.get('available')
        return computer

    def __repr__(self) -> str:
        return self.user_mac


def create_url() -> str:
    url = BASE_URL + '/manager/?'
    now = datetime.datetime.now()
    hour = now.strftime("%H:%M:00")
    date = now.strftime("%Y-%m-%d")
    url = url + f'hour={hour}&date={date}'
    return url


def do_request() -> List[dict]:
    """
    Request.

    :return: Request's Body
    """
    r = requests.get(create_url(), headers=HEADERS, verify='./ssl/consolidate.pem')
    return r.json()


def computers_request() -> List[dict]:
    r = requests.get(BASE_URL + "/manager/computers", headers=HEADERS, verify='./ssl/consolidate.pem')
    return r.json()


def computers_response() -> List[ComputerResponse]:
    body = computers_request()
    computers = []
    for i in body:
        computers.append(ComputerResponse.from_json(i))
    return computers


def request_manager() -> List[UserResponse]:
    """
    Make request and parse as a List of UserResponse.

    :return: List[UserResponse]
    """
    body = do_request()
    users = []
    for i in body:
        users.append(UserResponse.from_json(i))

    return users


def main():
    log(f'Starting Script at: {datetime.datetime.now()}')
    users = request_manager()
    computers = computers_response()
    logged_users = get_current_logged_users()

    users = list(filter(lambda x: x.computer == COMPUTER_NAME, users))
    user_names = list(map(lambda x: x.user_mac, users))

    computer_user = list(filter(lambda x: x.name == COMPUTER_NAME, computers))

    log(COMPUTER_NAME)
    if len(computer_user) > 0 and computer_user[0].available:
        for logged in logged_users:
            if logged not in user_names:
                logout_user(logged)
            else:
                log(f'User "{logged}" are in current session.')
    else:
        log(f'O computer "{COMPUTER_NAME}" is not available.')
    log('Finish Process')


if __name__ == '__main__':
    main()
    time.sleep(11)
