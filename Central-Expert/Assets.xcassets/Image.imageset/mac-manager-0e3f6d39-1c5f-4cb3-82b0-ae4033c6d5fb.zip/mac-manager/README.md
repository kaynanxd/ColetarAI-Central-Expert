# Python script to manage mac sessions

In order to keep running, this script will be runned by a deamon via plist in launchd.


Helpful Commands to know current logged in users:
Into LOGGED_IN_USER=`stat -f%Su /dev/console` can access current logged-in users.
w (only "w")
who 

To know more about Mac Deamons and services: https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/CreatingLaunchdJobs.html#//apple_ref/doc/uid/10000172i-SW7-BCIEDDBJ

Get Current user: https://stackoverflow.com/questions/29539316/get-logged-in-username-from-script-launched-by-launchdeamon

How to logout user in MAC: https://superuser.com/questions/40061/what-is-the-mac-os-x-terminal-command-to-log-out-the-current-user

# Default Process:

    1. Install brew in Mac and install gettext via brew:
    ```
        brew install gettext
        brew link --force gettext
    ``` 
    2. Copy files:
    ```
        scp -r ./mac-manager/ iosi@...:~/.mac-manager
        ssh iosi@... 
        # Inside:
        sudo mv ~/.mac-manager /opt/mac-manager; 
        cd /opt/mac-manager; 
        chmod +x ./cron-setup.sh;
    ```
    3. Setup `mac-manager.py` script variables.
    4. Install python requirements in sudo (root user): `pip install requests`
    5. Run `./cron-setup.sh` in Mac.
    5. If needed to remove cron from crontab, run `./cron-unsetup.sh`


# Processo Anydesk

Logar como Admin para abrir o anydesk. Bloquear tela e deixar na tela inicial.

# Adicionar itens em Platypus:

Para criar um AppImage é necessário usar o Platypus.

Run With root Privilegies. 

## MacManager Installer:
identifier: br.org.irede.MacManagerInstaller
Arquivos para Bundle:
 - mac-manager.py
 - cron-setup.sh
 - ssl/

## MacManager Uninstaller:
identifier: br.org.irede.MacManagerUninstaller
Arquivos de Bundle:
 - cron-unsetup.sh